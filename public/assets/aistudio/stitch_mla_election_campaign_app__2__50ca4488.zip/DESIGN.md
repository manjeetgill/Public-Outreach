---
name: Janadesh Civic Interface
colors:
  surface: '#f7f9ff'
  surface-dim: '#c1ddfc'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4ff'
  surface-container: '#e3efff'
  surface-container-high: '#d9eaff'
  surface-container-highest: '#cfe5ff'
  on-surface: '#001d33'
  on-surface-variant: '#43474d'
  inverse-surface: '#15324b'
  inverse-on-surface: '#e8f1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#00152a'
  on-primary: '#ffffff'
  primary-container: '#102a43'
  on-primary-container: '#7a92b0'
  inverse-primary: '#b0c9e8'
  secondary: '#a73a00'
  on-secondary: '#ffffff'
  secondary-container: '#fd651e'
  on-secondary-container: '#571a00'
  tertiary: '#001906'
  on-tertiary: '#ffffff'
  tertiary-container: '#003011'
  on-tertiary-container: '#40a25a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb599'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#95f8a7'
  tertiary-fixed-dim: '#79db8d'
  on-tertiary-fixed: '#00210a'
  on-tertiary-fixed-variant: '#005323'
  background: '#f7f9ff'
  on-background: '#001d33'
  surface-variant: '#cfe5ff'
typography:
  display-lg:
    fontFamily: Noto Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an authoritative, democratic, and deeply rooted digital presence for a state legislative re-election campaign. It balances constitutional sobriety with approachable, grass-roots energy. The visual tone rejects bombastic, fleeting campaign rhetoric in favor of verifiable accountability, civic transparency, and institutional dignity.

The design movement combines **Modern Civic Clarity** with **Information-Dense Utility**. It strips away visual clutter, prioritizing high-legibility content hierarchies, legible localized text rendering, and immediate access to governance track records. Every surface speaks to public duty, service continuity, and developmental momentum across multilingual constituencies.

## Colors

The palette is anchored in constitutional trust, energetic civic initiative, and grounded validation:

- **Primary (`#102A43` - Deep Royal Navy):** Evokes institutional authority, constitutional solemnity, and legislative accountability. Used for navigation bars, primary titles, critical metrics, and dominant action anchors.
- **Secondary (`#EA580C` - Saffron / Vibrant Amber):** Represents civic vitality, mobilization, community outreach, and urgent calls to action. Used for key conversion moments, volunteer drives, and highlighted milestones.
- **Tertiary (`#15803D` - Emerald Forest):** Represents developmental progress, delivered works, policy success rates, and affirmative validation across constituency report cards.
- **Neutral Palette (`#0B1B2B` to `#F8FAFC`):** Balanced, high-contrast grays and cool slates. Backgrounds rely on pristine off-whites (`#F8FAFC` for page canvas, `#FFFFFF` for elevated cards) to keep long-form reports legible under outdoor sunlight.
- **Functional Accent (`#25D366` - WhatsApp Green):** Dedicated strictly to mobile direct-share workflows, citizen peer distribution, and neighborhood grievance forwarding.

## Typography

The type system pairs **Noto Sans** for commanding headlines with **Inter** for dense transactional UI and multi-paragraph accountability narratives.

- **Multilingual Resilience:** Noto Sans provides reliable optical weight parity across English and regional Indic scripts (Hindi, Marathi, Telugu, Tamil, Bengali, or Kannada), preventing layout breakage in bilingual badges and localized legislative notices.
- **Tactical Scaling:** All mobile display sizes downscale gracefully to ensure no headline exceeds two lines on 360px-wide viewport screens.
- **Numbers and Metrics:** Report card metrics, development expenditures, and ward numbers leverage tabular figures (`font-variant-numeric: tabular-nums`) to preserve alignment across status matrices.

## Layout & Spacing

The layout is built upon an 8pt rhythmic grid system designed to support both wide dashboard viewports and low-bandwidth mobile devices common among constituents.

- **Mobile Viewports (<640px):** Single-column stack with minimum 48px touch targets, 1rem canvas margins, and edge-to-edge content cards. Spacing prioritizes thumb-zone interactions.
- **Tablet Viewports (640px - 1024px):** 6-column fluid structure with 1.5rem gutters; suitable for split grievance summaries and report-card comparisons.
- **Desktop Viewports (>1024px):** 12-column grid capped at a maximum width of `1280px`, ensuring comfortable reading lines and structured side navigation for ward-level drill-downs.
- **Density Control:** Form inputs, grievance records, and public expenditure lists use consistent structural gaps (`space-sm` to `space-md`), keeping data-dense reports compact and scannable without horizontal overflow.

## Elevation & Depth

Visual hierarchy uses **tonal layer stacking** combined with **restrained ambient shadows** to keep layouts clean and paper-like under harsh light.

- **Canvas Base (`#F8FAFC`):** Flat foundation for high-contrast presentation.
- **Elevated Surfaces (`#FFFFFF`):** Base report cards, citizen forms, and legislative scorecards utilize a soft border (`1px solid #E2E8F0`) combined with an ambient navy-tinted shadow: `0 1px 3px 0 rgba(16, 42, 67, 0.05), 0 1px 2px -1px rgba(16, 42, 67, 0.03)`.
- **Interactive Surfaces (Hover/Focus):** Lifted slightly with `0 4px 6px -1px rgba(16, 42, 67, 0.08), 0 2px 4px -2px rgba(16, 42, 67, 0.04)`.
- **Overlays & Drawers:** Used for Ward filter sheets and grievance filing panels. Elevated via `0 20px 25px -5px rgba(16, 42, 67, 0.12), 0 8px 10px -6px rgba(16, 42, 67, 0.08)` over a 50% opacity navy backdrop veil (`rgba(16, 42, 67, 0.5)`).

## Shapes

The design system adopts **Soft Geometry** (`roundedness: 1`). 

- Default elements (buttons, inputs, status badges) carry a `4px` (`0.25rem`) border radius, preserving institutional structure and avoiding overly playful curves.
- Larger elements like cards and modal containers use `8px` (`rounded-lg: 0.5rem`).
- Bilingual indicators and grievance tracking chips use `12px` (`rounded-xl: 0.75rem`) to stand out from structural grid elements.
- Circular elements are reserved strictly for MLA profile avatars, step numbers in grievance steppers, and social action buttons (e.g., floating WhatsApp action triggers).

## Components

### Buttons
- **Primary Civic Action:** Navy background (`#102A43`), white bold text, 48px min-height for immediate mobile touch reliability. Subtle focus ring: `3px solid rgba(234, 88, 12, 0.3)`.
- **Campaign Mobilization Action:** Warm Amber/Saffron (`#EA580C`), white text, used for "Join Campaign", "Volunteer", or "Submit Grievance".
- **WhatsApp Direct Action:** Field-tested green (`#25D366`), white icon and text, optimized for quick forwarding of manifesto points and ward accomplishments.

### Constituency Report Cards
- Solid white surface with a top accent bar: 4px solid `#15803D` for completed infrastructure, `#EA580C` for projects in progress.
- Split layout: Key performance indicators (e.g., "142km Roads Built", "98.4% Grievances Resolved") highlighted in bold display font alongside ward names and verified budget figures.

### Citizen Grievance Tracker
- Vertical stepped timeline component with clear state nodes: `Submitted`, `Under Review`, `Sanctioned`, `Work In Progress`, `Resolved`.
- Step states: Green checkmarks for resolved stages, pulsating saffron rings for active stages, and muted slate lines (`#CBD5E1`) for pending stages.
- Includes unique Tracking ID copy-to-clipboard button and direct WhatsApp status alert subscribe toggle.

### Bilingual Badges & Language Chips
- Inline pills combining regional script with English counterpart (e.g., `विकास कार्य | Development Work`).
- High-contrast border (`1px solid #CBD5E1`), background in `#F1F5F9`, typography styled in `label-sm` with explicit line-height buffers to prevent Indic font vowel cutoff.

### Form Fields & Inputs
- High-contrast border (`1.5px solid #94A3B8`) with explicit floating labels.
- Clear error states in `#DC2626` with localized help text.
- Large numeric keypad defaults on mobile for Citizen Voter ID (EPIC) and Mobile Number fields.